export interface AuthContextType{
  token: string | null;
  userId: string | null;
  username: string | null;
  profilePicture: string | null;
}
