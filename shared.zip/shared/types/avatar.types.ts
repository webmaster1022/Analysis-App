export interface AvatarTypes{
  name: string;
  id: string;
}
