export type user = {
  _id: string;
  userName: string;
  email: string;
  employeeId: string;
  profileImage: string;
};


