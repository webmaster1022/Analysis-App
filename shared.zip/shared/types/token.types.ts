export type token = {
  _id: string;
  role: string;
};
